class InvalidResponseException(Exception):
    pass


class InvalidEndpointException(Exception):
    pass


class InvalidURLException(Exception):
    pass
